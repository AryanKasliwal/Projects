public class PStatus_InProgress implements PStatus{

    @Override
    public String toString() {
        return "In-progress";
    }
}
