public class PStatus_Completed implements PStatus{

    @Override
    public String toString() {
        return "Completed";
    }
}
