public interface PStatus{
    @Override
    String toString();
}

