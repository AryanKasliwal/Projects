public interface command {
     void execute(String[] cmdInfo);
}

