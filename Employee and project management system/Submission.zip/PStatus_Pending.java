public class PStatus_Pending implements PStatus{

    @Override
    public String toString() {
        return "Pending";
    }
}
