Compile:
g++ demo.cpp -o demo

Run:
./demo demo_processes.txt demo_output.txt

where demo_processes.txt stores the process information, demo_output.txt is the output file path. Mutexes are not supported in the demo.